﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        //private const int Port = 5000;  // 라즈베리 파이와 동일한 포트 번호
        //private const string RaspberryPiIP = "192.168.8.132";  // 라즈베리 파이의 IP 주소

        public const string IPV4_REGEX = @"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";

        TcpClient Client;
        Thread ReciveThread;

        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tbIP.Text = "192.168.77.20"; // 기본 IP 번호
            tbIP.LostFocus += delegate (object sender2, EventArgs e2) 
            {
                UpdateIpAddress();

                if (!Regex.IsMatch(tbIP.Text, IPV4_REGEX))
                {
                    MessageBox.Show("IP 형식이 아닙니다.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    tbLog.Text += $"잘못된 IP 형식 입력 : {tbIP.Text}\r\n";
                }
            };


            tbPORT.Text = "5000"; // 기본 PORT 번호
            tbPORT.LostFocus += delegate (object sender2, EventArgs e2)
            {
                if (!int.TryParse(tbPORT.Text, out int port) || port < 0 || port > 65535)
                {
                    MessageBox.Show("잘못 된 PORT 번호", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    tbLog.Text += $"잘못 된 PORT 번 : {tbPORT.Text}\r\n";
                }
            };

            tbTimeOut.Text = "3";
            tbTimeOut.LostFocus += delegate (object sender2, EventArgs e2)
            {
                if (!int.TryParse(tbTimeOut.Text, out int timeout) || timeout < 0)
                {
                    MessageBox.Show("잘못 된 TIME OUT", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    tbLog.Text += $"잘못 된 TIME OUT : {tbTimeOut.Text}\r\n";
                }
            };
        }

        private void btnSocketConnect_Click(object sender, EventArgs e)
        {
            UpdateIpAddress();
            if (!IPAddress.TryParse(tbIP.Text, out IPAddress ip) ||
                !int.TryParse(tbPORT.Text, out int port) || port < 0 || port > 65535 ||
                !int.TryParse(tbTimeOut.Text, out int timeout) || timeout < 0)
            {
                tbLog.Text += "IP, PORT 또는 TIME OUT 값이 잘못 되었습니다.\r\n";
                tbLog.Text += $"IP : {tbIP.Text}, PORT : {tbPORT.Text}, TIME OUT : { tbTimeOut.Text}\r\n";
                return;
            }
            Connect(ip, port);
        }

        private void UpdateIpAddress()
        {
            string newText = string.Empty;
            bool isDot = true;
            foreach (char c in tbIP.Text)
            {
                if (c == '.') isDot = true;

                else
                {
                    if (isDot)
                    {
                        if (c == '0')
                            continue;
                        isDot = false;
                    }
                }
                newText += c;
            }

            tbIP.Text = newText;
        }

        private void Connect(IPAddress ip, int port)
        {
            if (Client?.Client != null && Client?.Connected == true)
            {
                tbLog.Text += "이미 소켓 연결이 되어 있습니다.\r\n";
                return;
            }


            Client = new TcpClient();
            
            IAsyncResult iar = Client.BeginConnect(ip, port, null, null);
            System.Threading.WaitHandle wh = iar.AsyncWaitHandle;

            try
            {
                int.TryParse(tbTimeOut.Text, out int timeout);
                if (!iar.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(timeout), false))
                {
                    tbLog.Text += "연결 시간이 초과되었습니다.\r\n";
                    Client.Close();
                }
                Client.EndConnect(iar);
            }
            catch (Exception ex)
            {
                tbLog.Text += ex.Message + "\n";
            }
            finally
            {
                wh.Close();
            }

            if (Client?.Client != null && Client?.Connected == true)
            {
                tbLog.Text += "소켓 연결이 완료되었습니다\r\n";
                ReciveThread = new Thread(() => ReceiveThreadAction(Client));
                ReciveThread.Start();
                tbLog.Text += "========서버로 부터 데이터 수신 시작======\r\n";
            }
            else
                tbLog.Text += "소켓 연결에 실패하였습니다.\r\n";
            
        }

        private void ReceiveThreadAction(TcpClient client)
        {
            NetworkStream stream = client.GetStream();

            try
            {
                while (true)
                {
                    byte[] data = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = stream.Read(data, 0, data.Length)) != 0)
                    {
                        byte[] incommingData = new byte[bytesRead];
                        Array.Copy(data, 0, incommingData, 0, bytesRead);

                        string message = Encoding.UTF8.GetString(incommingData);
                        if (tbLog.InvokeRequired)
                        {
                            tbLog.Invoke(new EventHandler(delegate {
                                tbLog.Text += $"서버로부터 데이터 수신: {message}\r\n";
                            }));
                        }
                        else
                            tbLog.Text += $"서버로부터 데이터 수신: {message}\r\n";

                        if (message == "quit")
                        {
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (tbLog.InvokeRequired)
                {
                    tbLog.Invoke(new EventHandler(delegate {
                        tbLog.Text += $"소켓 수신 스레드에서 예외 발생: {ex.Message}";
                    }));
                }
                else
                    tbLog.Text += $"소켓 수신 스레드에서 예외 발생: {ex.Message}";

            }

            if (tbLog.InvokeRequired)
            {
                tbLog.Invoke(new EventHandler(delegate {
                    btnSocketClose_Click(null, null);
                }));
            }
            else
                btnSocketClose_Click(null, null);

        }

        private void btnSocketClose_Click(object sender, EventArgs e)
        {
            if (ReciveThread != null)
            {
                tbLog.Text += "스레드를 중단 하는 중...\r\n";
                try
                {
                    ReciveThread.Abort();
                }
                catch(Exception ex)
                {
                    tbLog.Text += $"스레드 중단 중 예외발생 : {ex.Message}\r\n";
                }
            }
                

            if (Client?.Client != null && Client?.Connected == true)
            {
                tbLog.Text += "스트림 종료 중...\r\n";
                Client.GetStream().Close();
                tbLog.Text += "클라이언트 닫는 중...\r\n";
                Client.Close();
                tbLog.Text += "소켓 연결이 중단되었습니다.\r\n";
            }
            else
            {
                tbLog.Text += "소켓이 이미 연결되어 있지 않습니다.\r\n";
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (Client?.Client != null && Client?.Connected == true)
            {
                if (string.IsNullOrEmpty(tbSendText.Text))
                {
                    tbLog.Text += "전송할 텍스트가 비어 있습니다.\r\n";
                    return;
                }

                try
                {
                    byte[] sendBytes = Encoding.UTF8.GetBytes(tbSendText.Text);
                    NetworkStream stream = Client.GetStream();
                    stream.Write(sendBytes, 0, sendBytes.Length);

                    tbLog.Text += $"텍스트 전송 : {tbSendText.Text}\r\n";
                }
                catch(Exception ex)
                {
                    tbLog.Text += $"텍스트 전송 중 예외 발생 : {ex.Message}\r\n";
                }
                
            }
            else
            {
                tbLog.Text += "소켓이 연결되어 있지 않습니다.\r\n";
            }
        }
    }
}